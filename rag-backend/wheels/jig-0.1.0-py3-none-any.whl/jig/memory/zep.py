from __future__ import annotations

import logging
import uuid
from datetime import datetime
from inspect import isawaitable
from typing import Any

from jig.core.types import MemoryEntry, MemoryStore, Message, Retriever, Role

try:
    from zep_python.client import AsyncZep
except ImportError:
    AsyncZep = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)

_ROLE_TO_ZEP = {Role.USER: "human", Role.ASSISTANT: "ai", Role.TOOL: "tool"}
_ZEP_TO_ROLE = {"human": Role.USER, "ai": Role.ASSISTANT, "tool": Role.TOOL}


class ZepMemory(MemoryStore, Retriever):
    """Zep-backed memory. Implements both ``MemoryStore`` and ``Retriever``
    — Zep's service couples storage and retrieval. Instantiate once and
    pass to both ``store=`` and ``retriever=`` fields of
    :class:`AgentConfig`.
    """

    def __init__(self, session_id: str, **client_kwargs: Any):
        if AsyncZep is None:
            raise ImportError("Install zep: pip install 'jig[zep]'")
        self._client = AsyncZep(**client_kwargs)
        self._default_session_id = session_id
        self._closed = False

    async def close(self) -> None:
        """Release the owned Zep SDK client, if it exposes a close hook."""
        if self._closed:
            return

        aclose = getattr(self._client, "aclose", None)
        if callable(aclose):
            result = aclose()
            if isawaitable(result):
                await result
            self._closed = True
            return

        close = getattr(self._client, "close", None)
        if callable(close):
            result = close()
            if isawaitable(result):
                await result
        self._closed = True

    async def aclose(self) -> None:
        await self.close()

    async def _ensure_session(self, session_id: str) -> None:
        try:
            await self._client.memory.get(session_id)
        except Exception:
            await self._client.memory.add(session_id, messages=[])

    async def add(self, content: str, metadata: dict[str, Any] | None = None) -> str:
        entry_id = str(uuid.uuid4())
        await self._ensure_session(self._default_session_id)
        await self._client.memory.add(
            self._default_session_id,
            messages=[{"role": "system", "content": content, "metadata": metadata or {}}],
        )
        return entry_id

    async def get(self, id: str) -> MemoryEntry | None:
        # Zep stores messages, not discrete entries with IDs — return
        # None; use retrieve() for lookup.
        return None

    async def all(self) -> list[MemoryEntry]:
        # Zep doesn't expose cheap full-collection iteration.
        return []

    async def delete(self, id: str) -> None:
        # No per-entry delete in Zep's message model; clear() operates
        # at the session level.
        return None

    async def retrieve(
        self,
        query: str,
        k: int = 5,
        context: dict[str, Any] | None = None,
    ) -> list[MemoryEntry]:
        sid = (context or {}).get("session_id") or self._default_session_id
        try:
            results = await self._client.memory.search(sid, query, limit=k)
        except Exception:
            logger.warning("Zep search failed (session_id=%s)", sid, exc_info=True)
            return []

        return [
            MemoryEntry(
                id=str(uuid.uuid4()),
                content=r.message.get("content", "") if isinstance(r.message, dict) else r.message.content,
                metadata=r.metadata or {},
                score=r.score,
            )
            for r in results
        ]

    async def get_session(self, session_id: str) -> list[Message]:
        try:
            memory = await self._client.memory.get(session_id)
        except Exception:
            logger.warning("Zep session lookup failed (session_id=%s)", session_id, exc_info=True)
            return []

        messages: list[Message] = []
        for m in memory.messages or []:
            role = _ZEP_TO_ROLE.get(m.role, Role.USER)
            messages.append(Message(role=role, content=m.content))
        return messages

    async def add_to_session(self, session_id: str, message: Message) -> None:
        await self._ensure_session(session_id)
        zep_role = _ROLE_TO_ZEP.get(message.role, "human")
        await self._client.memory.add(
            session_id,
            messages=[{"role": zep_role, "content": message.content}],
        )

    async def clear(self, session_id: str | None = None, before: datetime | None = None) -> None:
        sid = session_id or self._default_session_id
        await self._client.memory.delete(sid)
